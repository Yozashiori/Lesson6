# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'e8e8adcc8185a26290aa32c878c3345b37711c23f66c7d87de9e779d613c46a0be9efd21e28ead4366348b08bfb356fc044fc0a937bc277ffce40f71a759f66b'
